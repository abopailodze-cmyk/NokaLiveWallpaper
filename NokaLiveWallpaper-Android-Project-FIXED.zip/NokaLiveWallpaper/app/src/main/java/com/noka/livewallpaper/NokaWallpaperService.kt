package com.noka.livewallpaper

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.sin
import kotlin.math.min

class NokaWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = NokaEngine()

    inner class NokaEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var bitmap: Bitmap? = null
        private var visible = false
        private var startTime = SystemClock.uptimeMillis()
        private val drawFrame = object : Runnable {
            override fun run() {
                draw()
                if (visible) handler.postDelayed(this, 40L)
            }
        }

        init {
            bitmap = BitmapFactory.decodeResource(resources, R.drawable.noka_character)
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            handler.removeCallbacks(drawFrame)
            if (visible) handler.post(drawFrame)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            draw()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawFrame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(drawFrame)
            bitmap?.recycle()
            bitmap = null
            super.onDestroy()
        }

        private fun draw() {
            val holder: SurfaceHolder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val w = canvas.width.toFloat()
                    val h = canvas.height.toFloat()
                    canvas.drawColor(android.graphics.Color.rgb(18, 26, 29))
                    val image = bitmap ?: return
                    val t = (SystemClock.uptimeMillis() - startTime) / 1000.0
                    // Slow side-to-side "walking" drift and gentle bobbing.
                    val scale = min(w / image.width, h / image.height) * 0.82f
                    val dw = image.width * scale
                    val dh = image.height * scale
                    val drift = sin(t * 1.1).toFloat() * w * 0.035f
                    val bob = sin(t * 4.0).toFloat() * h * 0.008f
                    val left = (w - dw) / 2f + drift
                    val top = (h - dh) / 2f + bob
                    canvas.save()
                    // Tiny sway gives the character a subtle animated presence.
                    canvas.rotate(sin(t * 1.6).toFloat() * 0.7f, w / 2f + drift, h / 2f + bob)
                    canvas.drawBitmap(image, null, RectF(left, top, left + dw, top + dh), paint)
                    canvas.restore()
                }
            } catch (_: Exception) {
                // Surface may be temporarily unavailable while the launcher changes screens.
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                }
            }
        }
    }
}
