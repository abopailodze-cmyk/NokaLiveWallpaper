# Noka Live Wallpaper (Android)

This Android Studio project uses the supplied Noka character image as a home-screen live wallpaper.

## What this first version does
- Displays Noka on the home screen as a live wallpaper.
- Adds gentle bobbing, subtle sway, and side-to-side drift to create a simple animated effect.
- Does not draw over other apps.

## Important limitation
This starter version animates the full image, so it does **not** independently blink the eyes or move the arm to wave. Those require separate artwork/layers or prepared animation frames. The project is source code, not a prebuilt APK.

## Build and install
1. Install Android Studio on a computer.
2. Open this `NokaLiveWallpaper` folder as a project.
3. Let Gradle sync; use JDK 17 if prompted.
4. Build > Build APK(s).
5. Install the generated APK on your Android phone.
6. On the phone, open **Settings > Wallpaper & style > Change wallpaper > Live wallpapers** (the exact labels vary by phone), choose **Noka — მოძრავი პერსონაჟი**, and apply it to **Home screen** only.

## Requirements
- Android Studio with Android Gradle Plugin support.
- Android 6.0 (API 23) or newer.
